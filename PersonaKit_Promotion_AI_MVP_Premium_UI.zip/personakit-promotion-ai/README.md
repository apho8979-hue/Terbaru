# PersonaKit Promotion — AI Image Studio MVP

## Isi proyek
- `public/index.html` — antarmuka aplikasi
- `public/style.css` — desain responsif untuk HP dan desktop
- `public/app.js` — interaksi UI dan pemanggilan API
- `server.js` — backend aman untuk memanggil OpenAI Images API
- `.env.example` — contoh konfigurasi API key

## Cara menjalankan di komputer/server Node.js
1. Install Node.js 20 atau lebih baru.
2. Ekstrak ZIP ini.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `OPENAI_API_KEY` di `.env`.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Catatan penting
- API key hanya disimpan di server `.env`, jangan dimasukkan ke `public/app.js`.
- Model gambar menggunakan `gpt-image-2.5-flare`; akses model/organisasi dan saldo API mungkin diperlukan.
- Permintaan dengan foto referensi menggunakan endpoint edit; tanpa foto menggunakan endpoint generate.
- Setiap proses dapat dikenakan biaya API. Periksa harga dan akses terkini sebelum dipakai pelanggan.
- Ini adalah MVP pengembangan, belum memiliki login, pembayaran, kuota pengguna, penyimpanan galeri cloud, atau perlindungan abuse/rate limit. Tambahkan sebelum dibuka untuk publik.
- Untuk pemakaian produksi, pasang HTTPS, autentikasi, rate limit, batas biaya, kebijakan privasi, dan penyimpanan yang aman.
- Foto referensi dikirim ke penyedia API untuk diproses. Beri tahu pengguna dan minta persetujuan sebelum upload.
