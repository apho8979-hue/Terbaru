const promptEl = document.getElementById("prompt");
const charCount = document.getElementById("charCount");
const modeCards = [...document.querySelectorAll(".mode-card")];
const referenceEl = document.getElementById("reference");
const generateBtn = document.getElementById("generateBtn");
const errorBox = document.getElementById("errorBox");
const resultImage = document.getElementById("resultImage");
const emptyState = document.getElementById("emptyState");
const loadingState = document.getElementById("loadingState");
const downloadBtn = document.getElementById("downloadBtn");
const resultStatus = document.getElementById("resultStatus");

const modePrompts = {
  branding: "Buat foto personal branding profesional, natural, elegan, kredibel, pencahayaan studio berkualitas, komposisi fotografi editorial. ",
  glamour: "Buat potret fashion glamor dengan aura percaya diri, ekspresi kuat, styling premium, pencahayaan sinematik, editorial high-fashion. ",
  luxury: "Buat visual luxury lifestyle yang sinematik, eksklusif, realistis, detail tinggi, komposisi fotografi komersial premium. ",
  business: "Buat materi visual promosi bisnis yang rapi, menarik, komersial, komposisi profesional, sisakan ruang bersih untuk teks desain. "
};
let selectedMode = "branding";

function setMode(mode) {
  selectedMode = mode;
  modeCards.forEach(card => card.classList.toggle("selected", card.dataset.mode === mode));
  document.querySelectorAll(".nav-item[data-mode]").forEach(link => {
    link.classList.toggle("active", link.dataset.mode === mode);
  });
}
modeCards.forEach(card => card.addEventListener("click", () => setMode(card.dataset.mode)));
document.querySelectorAll(".nav-item[data-mode]").forEach(link => {
  link.addEventListener("click", () => setMode(link.dataset.mode));
});

promptEl.addEventListener("input", () => {
  charCount.textContent = `${promptEl.value.length}/4000`;
});

referenceEl.addEventListener("change", () => {
  const file = referenceEl.files[0];
  document.getElementById("uploadTitle").textContent = file ? file.name : "Unggah foto Anda";
  document.getElementById("uploadSub").textContent = file
    ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Foto siap digunakan`
    : "JPG, PNG, WebP · Maksimal 8 MB";
});

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}
function clearError() {
  errorBox.hidden = true;
  errorBox.textContent = "";
}

generateBtn.addEventListener("click", async () => {
  clearError();
  const userPrompt = promptEl.value.trim();
  if (userPrompt.length < 8) {
    showError("Tulis deskripsi gambar minimal 8 karakter terlebih dahulu.");
    promptEl.focus();
    return;
  }
  const reference = referenceEl.files[0];
  if (reference && reference.size > 8 * 1024 * 1024) {
    showError("Ukuran foto maksimal 8 MB.");
    return;
  }

  const formData = new FormData();
  formData.append("prompt", modePrompts[selectedMode] + userPrompt);
  formData.append("size", document.getElementById("ratio").value);
  if (reference) formData.append("reference", reference);

  generateBtn.disabled = true;
  generateBtn.innerHTML = '<span>✦</span> Sedang membuat gambar...';
  emptyState.hidden = true;
  resultImage.hidden = true;
  loadingState.hidden = false;
  resultStatus.textContent = "AI sedang memproses";

  try {
    const response = await fetch("/api/generate", { method: "POST", body: formData });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Gagal membuat gambar.");
    resultImage.src = data.imageDataUrl;
    resultImage.hidden = false;
    loadingState.hidden = true;
    downloadBtn.href = data.imageDataUrl;
    downloadBtn.classList.remove("disabled");
    downloadBtn.setAttribute("aria-disabled", "false");
    resultStatus.textContent = "Gambar berhasil dibuat";
  } catch (error) {
    loadingState.hidden = true;
    emptyState.hidden = false;
    resultStatus.textContent = "Belum ada gambar";
    showError(error.message || "Terjadi kesalahan. Silakan coba lagi.");
  } finally {
    generateBtn.disabled = false;
    generateBtn.innerHTML = '<span>✦</span> Generate Gambar AI <span class="arrow">→</span>';
  }
});

// Cek apakah server aktif dan API key sudah dipasang.
fetch("/api/health")
  .then(r => r.json())
  .then(data => {
    if (!data.configured) showError("Mode tampilan siap. Untuk mengaktifkan AI sungguhan, pasang API key pada file .env di server.");
  })
  .catch(() => showError("Server belum terhubung. Jalankan aplikasi melalui perintah npm start."));
