require("dotenv").config();

const express = require("express");
const multer = require("multer");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const port = process.env.PORT || 3000;

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype)) {
      return cb(new Error("Gunakan foto JPG, PNG, atau WebP."));
    }
    cb(null, true);
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/generate", upload.single("reference"), async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({
        error: "API key belum dipasang. Isi OPENAI_API_KEY di file .env pada server."
      });
    }

    const prompt = String(req.body.prompt || "").trim();
    const size = ["1024x1024", "1024x1536", "1536x1024"].includes(req.body.size)
      ? req.body.size
      : "1024x1536";

    if (prompt.length < 8) {
      return res.status(400).json({ error: "Deskripsi gambar terlalu pendek." });
    }
    if (prompt.length > 4000) {
      return res.status(400).json({ error: "Deskripsi maksimal 4.000 karakter." });
    }

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const model = "gpt-image-2.5-flare";
    let result;

    if (req.file) {
      // Foto referensi diproses di server; API key tidak pernah dikirim ke browser.
      const imageFile = new File([req.file.buffer], req.file.originalname, {
        type: req.file.mimetype
      });
      result = await openai.images.edit({
        model,
        image: imageFile,
        prompt,
        size,
        quality: "medium"
      });
    } else {
      result = await openai.images.generate({
        model,
        prompt,
        size,
        quality: "medium",
        n: 1
      });
    }

    const image = result.data && result.data[0] && result.data[0].b64_json;
    if (!image) throw new Error("AI tidak mengembalikan gambar. Coba lagi.");

    res.json({
      imageDataUrl: `data:image/png;base64,${image}`,
      revisedPrompt: result.data[0].revised_prompt || null
    });
  } catch (error) {
    console.error("Image generation error:", error);
    const status = error.status && error.status >= 400 && error.status < 600 ? error.status : 500;
    res.status(status).json({
      error: error.message || "Terjadi kesalahan saat membuat gambar."
    });
  }
});

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || "Permintaan tidak valid." });
});

app.listen(port, () => {
  console.log(`PersonaKit berjalan di http://localhost:${port}`);
});
